
package InterfacesTarea;


public interface Usuario extends Persona {

   public abstract String getUsername();

    public abstract double getSaldo();

    public abstract void depositar(double cantidad);

    public abstract void retirar(double cantidad);
}
