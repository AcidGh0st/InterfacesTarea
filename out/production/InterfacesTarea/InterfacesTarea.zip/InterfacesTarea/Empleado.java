
package InterfacesTarea;


public interface Empleado extends Persona {

   public abstract String getCargo();

   public abstract int getId();


}
