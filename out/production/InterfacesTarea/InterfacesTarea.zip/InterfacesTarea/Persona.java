
package InterfacesTarea;

public interface Persona {

    public abstract String getNombre();

    public abstract int getEdad();


}
